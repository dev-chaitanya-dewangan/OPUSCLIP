module.exports = [
"[externals]/next/dist/compiled/next-server/app-page-turbo.runtime.dev.js [external] (next/dist/compiled/next-server/app-page-turbo.runtime.dev.js, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("next/dist/compiled/next-server/app-page-turbo.runtime.dev.js", () => require("next/dist/compiled/next-server/app-page-turbo.runtime.dev.js"));

module.exports = mod;
}),
"[project]/src/hooks/use-toast.ts [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "useToast",
    ()=>useToast
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react.js [app-ssr] (ecmascript)");
;
function useToast() {
    const [toasts, setToasts] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])([]);
    const toast = (props)=>{
        const id = Math.random().toString(36).substr(2, 9);
        const newToast = {
            id,
            ...props
        };
        setToasts((prev)=>[
                ...prev,
                newToast
            ]);
        // Auto dismiss after duration
        if (props.duration !== Infinity) {
            const duration = props.duration || 5000;
            setTimeout(()=>{
                dismiss(id);
            }, duration);
        }
        return {
            dismiss: ()=>dismiss(id)
        };
    };
    const dismiss = (id)=>{
        setToasts((prev)=>prev.filter((toast)=>toast.id !== id));
    };
    return {
        toasts,
        toast,
        dismiss
    };
}
}),
"[project]/src/components/ui/toaster.tsx [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "Toaster",
    ()=>Toaster
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react-jsx-dev-runtime.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$hooks$2f$use$2d$toast$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/hooks/use-toast.ts [app-ssr] (ecmascript)");
'use client';
;
;
function Toaster() {
    const { toasts } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$hooks$2f$use$2d$toast$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useToast"])();
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: "fixed top-4 right-4 z-50 space-y-2",
        children: toasts.map(({ id, title, description, variant })=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: `
            rounded-lg border p-4 shadow-lg transition-all duration-300
            ${variant === 'destructive' ? 'bg-destructive text-destructive-foreground border-destructive' : 'bg-background border'}
          `,
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "flex items-start",
                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "flex-1 space-y-1",
                        children: [
                            title && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("h3", {
                                className: "text-sm font-medium",
                                children: title
                            }, void 0, false, {
                                fileName: "[project]/src/components/ui/toaster.tsx",
                                lineNumber: 23,
                                columnNumber: 17
                            }, this),
                            description && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                className: "text-sm opacity-90",
                                children: description
                            }, void 0, false, {
                                fileName: "[project]/src/components/ui/toaster.tsx",
                                lineNumber: 28,
                                columnNumber: 17
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/src/components/ui/toaster.tsx",
                        lineNumber: 21,
                        columnNumber: 13
                    }, this)
                }, void 0, false, {
                    fileName: "[project]/src/components/ui/toaster.tsx",
                    lineNumber: 20,
                    columnNumber: 11
                }, this)
            }, id, false, {
                fileName: "[project]/src/components/ui/toaster.tsx",
                lineNumber: 11,
                columnNumber: 9
            }, this))
    }, void 0, false, {
        fileName: "[project]/src/components/ui/toaster.tsx",
        lineNumber: 9,
        columnNumber: 5
    }, this);
}
}),
"[externals]/next/dist/server/app-render/action-async-storage.external.js [external] (next/dist/server/app-render/action-async-storage.external.js, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("next/dist/server/app-render/action-async-storage.external.js", () => require("next/dist/server/app-render/action-async-storage.external.js"));

module.exports = mod;
}),
"[externals]/next/dist/server/app-render/work-unit-async-storage.external.js [external] (next/dist/server/app-render/work-unit-async-storage.external.js, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("next/dist/server/app-render/work-unit-async-storage.external.js", () => require("next/dist/server/app-render/work-unit-async-storage.external.js"));

module.exports = mod;
}),
"[externals]/next/dist/server/app-render/work-async-storage.external.js [external] (next/dist/server/app-render/work-async-storage.external.js, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("next/dist/server/app-render/work-async-storage.external.js", () => require("next/dist/server/app-render/work-async-storage.external.js"));

module.exports = mod;
}),
"[project]/src/lib/utils.ts [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

/**
 * Utility functions for the Opus Clip application
 */ __turbopack_context__.s([
    "cn",
    ()=>cn,
    "delay",
    ()=>delay,
    "safeLocalStorageGet",
    ()=>safeLocalStorageGet,
    "safeLocalStorageSet",
    ()=>safeLocalStorageSet,
    "timecode",
    ()=>timecode,
    "uid",
    ()=>uid
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$clsx$2f$dist$2f$clsx$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/clsx/dist/clsx.mjs [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$tailwind$2d$merge$2f$dist$2f$bundle$2d$mjs$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/tailwind-merge/dist/bundle-mjs.mjs [app-ssr] (ecmascript)");
;
;
function cn(...inputs) {
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$tailwind$2d$merge$2f$dist$2f$bundle$2d$mjs$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["twMerge"])((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$clsx$2f$dist$2f$clsx$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["clsx"])(inputs));
}
function delay(ms) {
    return new Promise((resolve)=>setTimeout(resolve, ms));
}
function uid(prefix = 'id') {
    return `${prefix}-${Math.random().toString(36).substr(2, 9)}`;
}
function timecode(seconds) {
    const h = Math.floor(seconds / 3600);
    const m = Math.floor(seconds % 3600 / 60);
    const s = Math.floor(seconds % 60);
    return [
        h.toString().padStart(2, '0'),
        m.toString().padStart(2, '0'),
        s.toString().padStart(2, '0')
    ].join(':');
}
function safeLocalStorageGet(key, defaultValue) {
    try {
        const item = localStorage.getItem(key);
        return item ? JSON.parse(item) : defaultValue;
    } catch (error) {
        console.error(`Error reading from localStorage key "${key}":`, error);
        return defaultValue;
    }
}
function safeLocalStorageSet(key, value) {
    try {
        localStorage.setItem(key, JSON.stringify(value));
    } catch (error) {
        console.error(`Error writing to localStorage key "${key}":`, error);
    }
}
}),
"[project]/src/lib/analytics.ts [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

/**
 * Analytics hook for tracking user interactions
 */ __turbopack_context__.s([
    "clearEvents",
    ()=>clearEvents,
    "getAllEvents",
    ()=>getAllEvents,
    "logEvent",
    ()=>logEvent,
    "useCtaClick",
    ()=>useCtaClick,
    "useInteraction",
    ()=>useInteraction,
    "usePageView",
    ()=>usePageView
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$utils$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/utils.ts [app-ssr] (ecmascript)");
;
;
const ANALYTICS_STORAGE_KEY = 'oc_analytics_events_v1';
const MAX_EVENTS = 100; // Limit to prevent storage bloat
// Get stored events
function getStoredEvents() {
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$utils$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["safeLocalStorageGet"])(ANALYTICS_STORAGE_KEY, []);
}
// Save events to localStorage
function saveEvents(events) {
    // Keep only the most recent events
    const recentEvents = events.slice(-MAX_EVENTS);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$utils$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["safeLocalStorageSet"])(ANALYTICS_STORAGE_KEY, recentEvents);
}
function logEvent(type, payload = {}) {
    const events = getStoredEvents();
    const event = {
        id: `event-${Date.now()}-${Math.random().toString(36).substr(2, 9)}`,
        type,
        payload,
        timestamp: new Date()
    };
    events.push(event);
    saveEvents(events);
    // Also log to console in development
    if ("TURBOPACK compile-time truthy", 1) {
        console.log(`[Analytics] ${type}:`, payload);
    }
}
function usePageView(pageName) {
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useEffect"])(()=>{
        logEvent('page_view', {
            page: pageName
        });
    }, [
        pageName
    ]);
}
function useCtaClick(ctaName) {
    return ()=>{
        logEvent('cta_click', {
            cta: ctaName
        });
    };
}
function useInteraction(interactionName) {
    return ()=>{
        logEvent('interaction', {
            interaction: interactionName
        });
    };
}
function getAllEvents() {
    return getStoredEvents();
}
function clearEvents() {
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$utils$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["safeLocalStorageSet"])(ANALYTICS_STORAGE_KEY, []);
}
}),
"[project]/src/components/analytics-provider.tsx [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "AnalyticsProvider",
    ()=>AnalyticsProvider
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/navigation.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$analytics$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/analytics.ts [app-ssr] (ecmascript)");
'use client';
;
;
;
function AnalyticsProvider() {
    const pathname = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["usePathname"])();
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useEffect"])(()=>{
        // Log page view when pathname changes
        (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$analytics$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["logEvent"])('page_view', {
            path: pathname
        });
    }, [
        pathname
    ]);
    // This component doesn't render anything
    return null;
}
}),
"[project]/src/lib/fixtures.ts [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

/**
 * Deterministic seed data for the Opus Clip application
 */ __turbopack_context__.s([
    "captionBlocks",
    ()=>captionBlocks,
    "clips",
    ()=>clips,
    "featureCards",
    ()=>featureCards,
    "fixtures",
    ()=>fixtures,
    "logos",
    ()=>logos,
    "plans",
    ()=>plans,
    "projects",
    ()=>projects,
    "socialAccounts",
    ()=>socialAccounts,
    "timelineSegments",
    ()=>timelineSegments,
    "userProfile",
    ()=>userProfile,
    "workflowItems",
    ()=>workflowItems
]);
const userProfile = {
    id: 'user-1',
    name: 'Alex Johnson',
    email: 'alex@example.com',
    role: 'creator',
    preferredAspectRatio: '9:16',
    createdAt: new Date('2023-01-15'),
    updatedAt: new Date('2023-06-20')
};
const socialAccounts = [
    {
        id: 'social-1',
        platform: 'youtube',
        username: 'alexjohnson',
        connected: true,
        profileUrl: 'https://youtube.com/@alexjohnson'
    },
    {
        id: 'social-2',
        platform: 'tiktok',
        username: 'alexjohnson',
        connected: false
    },
    {
        id: 'social-3',
        platform: 'instagram',
        username: 'alexjohnson',
        connected: true,
        profileUrl: 'https://instagram.com/alexjohnson'
    }
];
const logos = [
    {
        id: 'logo-1',
        name: 'Company A',
        src: '/images/logo-a.png'
    },
    {
        id: 'logo-2',
        name: 'Company B',
        src: '/images/logo-b.png'
    },
    {
        id: 'logo-3',
        name: 'Company C',
        src: '/images/logo-c.png'
    },
    {
        id: 'logo-4',
        name: 'Company D',
        src: '/images/logo-d.png'
    },
    {
        id: 'logo-5',
        name: 'Company E',
        src: '/images/logo-e.png'
    }
];
const featureCards = [
    {
        id: 'feature-1',
        title: 'AI Models',
        description: 'Leverage cutting-edge AI to enhance your video content automatically',
        icon: '🤖'
    },
    {
        id: 'feature-2',
        title: 'Clip Anything',
        description: 'Transform long videos into engaging clips with one click',
        icon: '✂️'
    },
    {
        id: 'feature-3',
        title: 'Reframe Anything',
        description: 'Automatically reframe your content for different aspect ratios',
        icon: '📱'
    }
];
const workflowItems = [
    {
        id: 'workflow-1',
        title: 'Auto Import',
        description: 'Connect your video sources for automatic importing',
        icon: '📥',
        completed: true
    },
    {
        id: 'workflow-2',
        title: 'Auto Edit',
        description: 'Let AI create engaging clips from your content',
        icon: '✂️',
        completed: true
    },
    {
        id: 'workflow-3',
        title: 'Auto Scheduling',
        description: 'Schedule your content across platforms',
        icon: '🗓️',
        completed: false
    }
];
const plans = [
    {
        id: 'plan-1',
        name: 'Overlap Pro',
        description: 'Perfect for individual creators',
        price: {
            monthly: 29,
            annual: 290 // 29 * 10 months = 20% discount
        },
        features: [
            '100 video minutes/month',
            'AI-powered editing',
            'Auto-captioning',
            'Export in 1080p',
            'Basic analytics'
        ],
        isRecommended: false,
        isTrial: true,
        trialDays: 7
    },
    {
        id: 'plan-2',
        name: 'Overlap Team',
        description: 'For growing teams and agencies',
        price: {
            monthly: 99,
            annual: 990 // 99 * 10 months = 20% discount
        },
        features: [
            '1000 video minutes/month',
            'All Pro features',
            'Team collaboration',
            'Export in 4K',
            'Advanced analytics',
            'Priority support'
        ],
        isRecommended: true,
        isTrial: true,
        trialDays: 14
    }
];
const projects = [
    {
        id: 'project-1',
        slug: 'lex-408',
        title: 'Demo project: Lex #408',
        description: 'Interview with Lex Fridman',
        thumbnail: {
            square: '/images/thumbnail-square-1.png',
            vertical: '/images/thumbnail-vertical-1.png'
        },
        videoSrc: '/videos/sample-1.mp4',
        poster: '/images/poster-1.png',
        duration: 3600,
        points: 1200,
        createdAt: new Date('2023-05-15'),
        updatedAt: new Date('2023-05-15')
    },
    {
        id: 'project-2',
        slug: 'curry-drills',
        title: 'Curry Drills 12 Threes',
        description: 'Basketball training session',
        thumbnail: {
            square: '/images/thumbnail-square-2.png',
            vertical: '/images/thumbnail-vertical-2.png'
        },
        videoSrc: '/videos/sample-2.mp4',
        poster: '/images/poster-2.png',
        duration: 1800,
        points: 800,
        createdAt: new Date('2023-06-01'),
        updatedAt: new Date('2023-06-01')
    },
    {
        id: 'project-3',
        slug: 'danny-duncan',
        title: 'Interview with Danny Duncan',
        description: 'Skateboarding legend interview',
        thumbnail: {
            square: '/images/thumbnail-square-3.png',
            vertical: '/images/thumbnail-vertical-3.png'
        },
        videoSrc: '/videos/sample-3.mp4',
        poster: '/images/poster-3.png',
        duration: 2700,
        points: 1000,
        createdAt: new Date('2023-06-10'),
        updatedAt: new Date('2023-06-10')
    },
    {
        id: 'project-4',
        slug: 'learning-center',
        title: 'Learning center',
        description: 'Educational content series',
        thumbnail: {
            square: '/images/thumbnail-square-4.png',
            vertical: '/images/thumbnail-vertical-4.png'
        },
        videoSrc: '/videos/sample-4.mp4',
        poster: '/images/poster-4.png',
        duration: 1200,
        points: 600,
        createdAt: new Date('2023-06-15'),
        updatedAt: new Date('2023-06-15')
    },
    {
        id: 'project-5',
        slug: 'tech-review',
        title: 'Latest Tech Review',
        description: 'Gadget reviews and analysis',
        thumbnail: {
            square: '/images/thumbnail-square-5.png',
            vertical: '/images/thumbnail-vertical-5.png'
        },
        videoSrc: '/videos/sample-5.mp4',
        poster: '/images/poster-5.png',
        duration: 2100,
        points: 900,
        createdAt: new Date('2023-06-18'),
        updatedAt: new Date('2023-06-18')
    },
    {
        id: 'project-6',
        slug: 'cooking-tutorial',
        title: 'Masterclass: Italian Cuisine',
        description: 'Learn to cook authentic Italian dishes',
        thumbnail: {
            square: '/images/thumbnail-square-6.png',
            vertical: '/images/thumbnail-vertical-6.png'
        },
        videoSrc: '/videos/sample-6.mp4',
        poster: '/images/poster-6.png',
        duration: 3000,
        points: 1100,
        createdAt: new Date('2023-06-20'),
        updatedAt: new Date('2023-06-20')
    }
];
const clips = {
    'project-1': [
        {
            id: 'clip-1-1',
            projectId: 'project-1',
            title: 'Introduction',
            start: 0,
            end: 120
        },
        {
            id: 'clip-1-2',
            projectId: 'project-1',
            title: 'AI and Consciousness',
            start: 120,
            end: 600
        },
        {
            id: 'clip-1-3',
            projectId: 'project-1',
            title: 'The Future of Robotics',
            start: 600,
            end: 1200
        },
        {
            id: 'clip-1-4',
            projectId: 'project-1',
            title: 'Neural Networks Explained',
            start: 1200,
            end: 1800
        },
        {
            id: 'clip-1-5',
            projectId: 'project-1',
            title: 'Ethics in AI',
            start: 1800,
            end: 2400
        },
        {
            id: 'clip-1-6',
            projectId: 'project-1',
            title: 'Closing Thoughts',
            start: 2400,
            end: 3600
        }
    ],
    'project-2': [
        {
            id: 'clip-2-1',
            projectId: 'project-2',
            title: 'Warm-up Drills',
            start: 0,
            end: 300
        },
        {
            id: 'clip-2-2',
            projectId: 'project-2',
            title: 'Ball Handling',
            start: 300,
            end: 600
        },
        {
            id: 'clip-2-3',
            projectId: 'project-2',
            title: 'Shooting Form',
            start: 600,
            end: 900
        },
        {
            id: 'clip-2-4',
            projectId: 'project-2',
            title: 'Three-Point Practice',
            start: 900,
            end: 1500
        },
        {
            id: 'clip-2-5',
            projectId: 'project-2',
            title: 'Cool Down',
            start: 1500,
            end: 1800
        }
    ],
    'project-3': [
        {
            id: 'clip-3-1',
            projectId: 'project-3',
            title: 'Early Life',
            start: 0,
            end: 300
        },
        {
            id: 'clip-3-2',
            projectId: 'project-3',
            title: 'Rise to Fame',
            start: 300,
            end: 900
        },
        {
            id: 'clip-3-3',
            projectId: 'project-3',
            title: 'Signature Tricks',
            start: 900,
            end: 1500
        },
        {
            id: 'clip-3-4',
            projectId: 'project-3',
            title: 'Life Philosophy',
            start: 1500,
            end: 2100
        },
        {
            id: 'clip-3-5',
            projectId: 'project-3',
            title: 'Future Goals',
            start: 2100,
            end: 2700
        }
    ],
    'project-4': [
        {
            id: 'clip-4-1',
            projectId: 'project-4',
            title: 'Welcome',
            start: 0,
            end: 120
        },
        {
            id: 'clip-4-2',
            projectId: 'project-4',
            title: 'Basic Concepts',
            start: 120,
            end: 420
        },
        {
            id: 'clip-4-3',
            projectId: 'project-4',
            title: 'Hands-on Demo',
            start: 420,
            end: 840
        },
        {
            id: 'clip-4-4',
            projectId: 'project-4',
            title: 'Advanced Techniques',
            start: 840,
            end: 1200
        }
    ],
    'project-5': [
        {
            id: 'clip-5-1',
            projectId: 'project-5',
            title: 'Product Overview',
            start: 0,
            end: 300
        },
        {
            id: 'clip-5-2',
            projectId: 'project-5',
            title: 'Unboxing',
            start: 300,
            end: 600
        },
        {
            id: 'clip-5-3',
            projectId: 'project-5',
            title: 'Performance Tests',
            start: 600,
            end: 1200
        },
        {
            id: 'clip-5-4',
            projectId: 'project-5',
            title: 'Pros and Cons',
            start: 1200,
            end: 1650
        },
        {
            id: 'clip-5-5',
            projectId: 'project-5',
            title: 'Final Verdict',
            start: 1650,
            end: 2100
        }
    ],
    'project-6': [
        {
            id: 'clip-6-1',
            projectId: 'project-6',
            title: 'Ingredients',
            start: 0,
            end: 300
        },
        {
            id: 'clip-6-2',
            projectId: 'project-6',
            title: 'Pasta Making',
            start: 300,
            end: 900
        },
        {
            id: 'clip-6-3',
            projectId: 'project-6',
            title: 'Sauce Preparation',
            start: 900,
            end: 1500
        },
        {
            id: 'clip-6-4',
            projectId: 'project-6',
            title: 'Cooking Techniques',
            start: 1500,
            end: 2400
        },
        {
            id: 'clip-6-5',
            projectId: 'project-6',
            title: 'Plating and Serving',
            start: 2400,
            end: 3000
        }
    ]
};
const captionBlocks = {
    'clip-1-1': [
        {
            id: 'caption-1-1-1',
            clipId: 'clip-1-1',
            start: 0,
            end: 30,
            text: 'Welcome to another episode of the Lex Fridman Podcast'
        },
        {
            id: 'caption-1-1-2',
            clipId: 'clip-1-1',
            start: 30,
            end: 60,
            text: 'Today we have a fascinating guest who has made significant contributions'
        },
        {
            id: 'caption-1-1-3',
            clipId: 'clip-1-1',
            start: 60,
            end: 90,
            text: 'to the field of artificial intelligence and robotics'
        },
        {
            id: 'caption-1-1-4',
            clipId: 'clip-1-1',
            start: 90,
            end: 120,
            text: 'Please welcome our guest for today'
        }
    ],
    'clip-2-1': [
        {
            id: 'caption-2-1-1',
            clipId: 'clip-2-1',
            start: 0,
            end: 60,
            text: 'Before we start with the intense drills, lets do a proper warm-up'
        },
        {
            id: 'caption-2-1-2',
            clipId: 'clip-2-1',
            start: 60,
            end: 120,
            text: 'This will help prevent injuries and prepare your muscles'
        },
        {
            id: 'caption-2-1-3',
            clipId: 'clip-2-1',
            start: 120,
            end: 180,
            text: 'We will do 5 minutes of light jogging followed by stretching'
        },
        {
            id: 'caption-2-1-4',
            clipId: 'clip-2-1',
            start: 180,
            end: 240,
            text: 'Focus on your breathing and keeping a steady pace'
        },
        {
            id: 'caption-2-1-5',
            clipId: 'clip-2-1',
            start: 240,
            end: 300,
            text: 'Remember, warming up is just as important as the main workout'
        }
    ]
};
const timelineSegments = {
    'project-1': [
        {
            id: 'segment-1-1',
            projectId: 'project-1',
            start: 0,
            end: 120,
            type: 'clip',
            clipId: 'clip-1-1'
        },
        {
            id: 'segment-1-2',
            projectId: 'project-1',
            start: 120,
            end: 600,
            type: 'clip',
            clipId: 'clip-1-2'
        },
        {
            id: 'segment-1-3',
            projectId: 'project-1',
            start: 600,
            end: 1200,
            type: 'clip',
            clipId: 'clip-1-3'
        }
    ],
    'project-2': [
        {
            id: 'segment-2-1',
            projectId: 'project-2',
            start: 0,
            end: 300,
            type: 'clip',
            clipId: 'clip-2-1'
        },
        {
            id: 'segment-2-2',
            projectId: 'project-2',
            start: 300,
            end: 600,
            type: 'clip',
            clipId: 'clip-2-2'
        },
        {
            id: 'segment-2-3',
            projectId: 'project-2',
            start: 600,
            end: 900,
            type: 'clip',
            clipId: 'clip-2-3'
        }
    ]
};
const fixtures = {
    userProfile,
    socialAccounts,
    logos,
    featureCards,
    workflowItems,
    plans,
    projects,
    clips,
    captionBlocks,
    timelineSegments
};
}),
"[project]/src/lib/db.ts [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

/**
 * In-memory database with localStorage persistence for the Opus Clip application
 */ __turbopack_context__.s([
    "createProject",
    ()=>createProject,
    "getProfile",
    ()=>getProfile,
    "getProject",
    ()=>getProject,
    "initializeDb",
    ()=>initializeDb,
    "listClips",
    ()=>listClips,
    "listFeatures",
    ()=>listFeatures,
    "listLogos",
    ()=>listLogos,
    "listPlans",
    ()=>listPlans,
    "listProjects",
    ()=>listProjects,
    "listWorkflow",
    ()=>listWorkflow,
    "resetDb",
    ()=>resetDb,
    "updateClip",
    ()=>updateClip,
    "updateProfile",
    ()=>updateProfile,
    "updateProject",
    ()=>updateProject
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$utils$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/utils.ts [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$fixtures$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/fixtures.ts [app-ssr] (ecmascript)");
;
;
// Storage keys with versioning
const STORAGE_KEYS = {
    PROFILE: 'oc_profile_v1',
    PROJECTS: 'oc_projects_v1',
    CLIPS: 'oc_clips_v1',
    CAPTIONS: 'oc_captions_v1',
    TIMELINE: 'oc_timeline_v1',
    LAST_SAVED: 'oc_last_saved_v1'
};
// In-memory storage
const db = {
    profile: null,
    projects: {},
    clips: {},
    captions: {},
    timeline: {},
    logos: [],
    features: [],
    workflow: [],
    plans: [],
    socialAccounts: []
};
async function initializeDb() {
    // Simulate network delay
    await (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$utils$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["delay"])(100);
    // Load from localStorage or use fixtures
    db.profile = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$utils$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["safeLocalStorageGet"])(STORAGE_KEYS.PROFILE, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$fixtures$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["fixtures"].userProfile);
    const storedProjects = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$utils$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["safeLocalStorageGet"])(STORAGE_KEYS.PROJECTS, null);
    if (storedProjects) {
        db.projects = storedProjects;
    } else {
        // Convert array to record by id
        db.projects = __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$fixtures$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["fixtures"].projects.reduce((acc, project)=>{
            acc[project.id] = project;
            return acc;
        }, {});
    }
    const storedClips = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$utils$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["safeLocalStorageGet"])(STORAGE_KEYS.CLIPS, null);
    if (storedClips) {
        db.clips = storedClips;
    } else {
        db.clips = __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$fixtures$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["fixtures"].clips;
    }
    const storedCaptions = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$utils$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["safeLocalStorageGet"])(STORAGE_KEYS.CAPTIONS, null);
    if (storedCaptions) {
        db.captions = storedCaptions;
    } else {
        db.captions = __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$fixtures$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["fixtures"].captionBlocks;
    }
    const storedTimeline = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$utils$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["safeLocalStorageGet"])(STORAGE_KEYS.TIMELINE, null);
    if (storedTimeline) {
        db.timeline = storedTimeline;
    } else {
        db.timeline = __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$fixtures$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["fixtures"].timelineSegments;
    }
    // Static data always comes from fixtures
    db.logos = __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$fixtures$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["fixtures"].logos;
    db.features = __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$fixtures$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["fixtures"].featureCards;
    db.workflow = __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$fixtures$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["fixtures"].workflowItems;
    db.plans = __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$fixtures$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["fixtures"].plans;
    db.socialAccounts = __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$fixtures$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["fixtures"].socialAccounts;
}
// Save database to localStorage
function saveToLocalStorage() {
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$utils$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["safeLocalStorageSet"])(STORAGE_KEYS.PROFILE, db.profile);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$utils$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["safeLocalStorageSet"])(STORAGE_KEYS.PROJECTS, db.projects);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$utils$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["safeLocalStorageSet"])(STORAGE_KEYS.CLIPS, db.clips);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$utils$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["safeLocalStorageSet"])(STORAGE_KEYS.CAPTIONS, db.captions);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$utils$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["safeLocalStorageSet"])(STORAGE_KEYS.TIMELINE, db.timeline);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$utils$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["safeLocalStorageSet"])(STORAGE_KEYS.LAST_SAVED, new Date().toISOString());
}
async function resetDb() {
    // Clear all data
    db.profile = null;
    db.projects = {};
    db.clips = {};
    db.captions = {};
    db.timeline = {};
    // Reinitialize with fixtures
    await initializeDb();
    // Clear localStorage
    Object.values(STORAGE_KEYS).forEach((key)=>{
        localStorage.removeItem(key);
    });
    // Save to localStorage
    saveToLocalStorage();
}
async function getProfile() {
    await (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$utils$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["delay"])(50);
    if (!db.profile) {
        throw new Error('User profile not found');
    }
    return db.profile;
}
async function updateProfile(patch) {
    await (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$utils$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["delay"])(100);
    if (!db.profile) {
        throw new Error('User profile not found');
    }
    db.profile = {
        ...db.profile,
        ...patch,
        updatedAt: new Date()
    };
    saveToLocalStorage();
    return db.profile;
}
async function listProjects() {
    await (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$utils$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["delay"])(150);
    return Object.values(db.projects).sort((a, b)=>new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());
}
async function getProject(id) {
    await (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$utils$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["delay"])(50);
    const project = db.projects[id];
    if (!project) {
        throw new Error(`Project with id ${id} not found`);
    }
    return project;
}
async function createProject(input) {
    await (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$utils$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["delay"])(200);
    const now = new Date();
    const newProject = {
        id: input.id || `project-${Date.now()}`,
        slug: input.slug || `project-${Date.now()}`,
        title: input.title || 'Untitled Project',
        description: input.description || '',
        thumbnail: input.thumbnail || {
            square: '/images/placeholder-square.png',
            vertical: '/images/placeholder-vertical.png'
        },
        videoSrc: input.videoSrc || '/videos/sample.mp4',
        poster: input.poster || '/images/poster.png',
        duration: input.duration || 600,
        points: input.points || 0,
        createdAt: input.createdAt || now,
        updatedAt: now
    };
    db.projects[newProject.id] = newProject;
    // Create default clips for the project
    const defaultClips = [];
    const segmentLength = Math.floor(newProject.duration / 5); // 5 default clips
    for(let i = 0; i < 5; i++){
        defaultClips.push({
            id: `clip-${newProject.id}-${i + 1}`,
            projectId: newProject.id,
            title: `Clip ${i + 1}`,
            start: i * segmentLength,
            end: (i + 1) * segmentLength
        });
    }
    db.clips[newProject.id] = defaultClips;
    // Create default timeline segments
    db.timeline[newProject.id] = defaultClips.map((clip, index)=>({
            id: `segment-${newProject.id}-${index + 1}`,
            projectId: newProject.id,
            start: clip.start,
            end: clip.end,
            type: 'clip',
            clipId: clip.id
        }));
    saveToLocalStorage();
    return newProject;
}
async function updateProject(id, patch) {
    await (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$utils$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["delay"])(100);
    const project = db.projects[id];
    if (!project) {
        throw new Error(`Project with id ${id} not found`);
    }
    db.projects[id] = {
        ...project,
        ...patch,
        updatedAt: new Date()
    };
    saveToLocalStorage();
    return db.projects[id];
}
async function listClips(projectId) {
    await (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$utils$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["delay"])(50);
    return db.clips[projectId] || [];
}
async function updateClip(projectId, clipId, patch) {
    await (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$utils$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["delay"])(100);
    const clips = db.clips[projectId];
    if (!clips) {
        throw new Error(`Clips for project ${projectId} not found`);
    }
    const clipIndex = clips.findIndex((c)=>c.id === clipId);
    if (clipIndex === -1) {
        throw new Error(`Clip with id ${clipId} not found`);
    }
    clips[clipIndex] = {
        ...clips[clipIndex],
        ...patch
    };
    saveToLocalStorage();
    return clips[clipIndex];
}
async function listPlans() {
    await (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$utils$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["delay"])(50);
    return db.plans;
}
async function listLogos() {
    await (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$utils$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["delay"])(50);
    return db.logos;
}
async function listFeatures() {
    await (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$utils$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["delay"])(50);
    return db.features;
}
async function listWorkflow() {
    await (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$utils$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["delay"])(50);
    return db.workflow;
}
// Initialize the database on module load, but only on client side
if ("TURBOPACK compile-time falsy", 0) //TURBOPACK unreachable
;
}),
"[project]/src/lib/store.ts [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

/**
 * Zustand store for the Opus Clip application
 */ __turbopack_context__.s([
    "useStore",
    ()=>useStore
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$zustand$2f$esm$2f$react$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/zustand/esm/react.mjs [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$zustand$2f$esm$2f$middleware$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/zustand/esm/middleware.mjs [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$db$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/db.ts [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$utils$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/utils.ts [app-ssr] (ecmascript)");
;
;
;
;
const initialProjectsState = {
    entities: {},
    ids: [],
    loading: false,
    error: null
};
const createProjectsSlice = (set)=>({
        ...initialProjectsState,
        fetchProjects: async ()=>{
            set({
                loading: true,
                error: null
            });
            try {
                const projects = await __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$db$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["listProjects"]();
                const entities = projects.reduce((acc, project)=>{
                    acc[project.id] = project;
                    return acc;
                }, {});
                set({
                    entities,
                    ids: projects.map((p)=>p.id),
                    loading: false
                });
            } catch (error) {
                set({
                    loading: false,
                    error: error instanceof Error ? error.message : 'Failed to fetch projects'
                });
            }
        },
        createProject: async (input)=>{
            try {
                const project = await __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$db$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["createProject"](input);
                set((state)=>({
                        entities: {
                            ...state.entities,
                            [project.id]: project
                        },
                        ids: [
                            project.id,
                            ...state.ids
                        ]
                    }));
                return project;
            } catch (error) {
                set({
                    error: error instanceof Error ? error.message : 'Failed to create project'
                });
                throw error;
            }
        },
        updateProject: async (id, patch)=>{
            try {
                await __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$db$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["updateProject"](id, patch);
                set((state)=>({
                        entities: {
                            ...state.entities,
                            [id]: {
                                ...state.entities[id],
                                ...patch
                            }
                        }
                    }));
            } catch (error) {
                set({
                    error: error instanceof Error ? error.message : 'Failed to update project'
                });
                throw error;
            }
        },
        deleteProject: async (id)=>{
            // In a real app, we would delete from the database
            set((state)=>({
                    entities: Object.fromEntries(Object.entries(state.entities).filter(([key])=>key !== id)),
                    ids: state.ids.filter((i)=>i !== id)
                }));
        },
        refreshProjects: async ()=>{
            // Re-fetch all projects
            // This would call fetchProjects if we had a reference to it
            console.log('Refresh projects called');
        }
    });
const initialEditorState = {
    activeProjectId: null,
    currentTime: 0,
    duration: 0,
    playing: false,
    selectedClipId: null,
    captionsVisible: true,
    reframeEnabled: false,
    aspect: '9:16',
    selectionStart: null,
    selectionEnd: null,
    keyboardShortcutsEnabled: true,
    lastSavedAt: null
};
const createEditorSlice = (set)=>({
        ...initialEditorState,
        setActiveProject: (id)=>set({
                activeProjectId: id
            }),
        setCurrentTime: (time)=>set({
                currentTime: time
            }),
        setDuration: (duration)=>set({
                duration
            }),
        play: ()=>set({
                playing: true
            }),
        pause: ()=>set({
                playing: false
            }),
        togglePlay: ()=>set((state)=>({
                    playing: !state.playing
                })),
        selectClip: (id)=>set({
                selectedClipId: id
            }),
        toggleCaptions: ()=>set((state)=>({
                    captionsVisible: !state.captionsVisible
                })),
        toggleReframe: ()=>set((state)=>({
                    reframeEnabled: !state.reframeEnabled
                })),
        setAspect: (aspect)=>set({
                aspect
            }),
        setSelectionStart: (time)=>set({
                selectionStart: time
            }),
        setSelectionEnd: (time)=>set({
                selectionEnd: time
            }),
        clearSelection: ()=>set({
                selectionStart: null,
                selectionEnd: null
            }),
        splitAtPlayhead: ()=>{
            // Implementation would go here
            console.log('Split at playhead');
        },
        markIn: ()=>set((state)=>({
                    selectionStart: state.currentTime
                })),
        markOut: ()=>set((state)=>({
                    selectionEnd: state.currentTime
                })),
        saveProject: async ()=>{
            // Simulate saving
            await (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$utils$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["delay"])(500);
            set({
                lastSavedAt: new Date()
            });
        },
        toggleKeyboardShortcuts: ()=>set((state)=>({
                    keyboardShortcutsEnabled: !state.keyboardShortcutsEnabled
                }))
    });
const useStore = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$zustand$2f$esm$2f$react$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["create"])()((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$zustand$2f$esm$2f$middleware$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["persist"])((set)=>({
        ...createProjectsSlice(set),
        ...createEditorSlice(set)
    }), {
    name: 'opus-clip-storage',
    partialize: (state)=>({
            aspect: state.aspect,
            captionsVisible: state.captionsVisible,
            reframeEnabled: state.reframeEnabled
        })
}));
}),
"[project]/src/components/debug-panel.tsx [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "DebugPanel",
    ()=>DebugPanel
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react-jsx-dev-runtime.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$store$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/store.ts [app-ssr] (ecmascript)");
'use client';
;
;
function DebugPanel() {
    const { ids, activeProjectId, currentTime, playing } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$store$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useStore"])();
    if ("TURBOPACK compile-time falsy", 0) //TURBOPACK unreachable
    ;
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: "fixed bottom-0 left-0 right-0 bg-black text-white p-4 text-xs z-50",
        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: "container",
            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "flex flex-wrap gap-4",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("strong", {
                                children: "Projects:"
                            }, void 0, false, {
                                fileName: "[project]/src/components/debug-panel.tsx",
                                lineNumber: 22,
                                columnNumber: 13
                            }, this),
                            " ",
                            ids.length,
                            " loaded"
                        ]
                    }, void 0, true, {
                        fileName: "[project]/src/components/debug-panel.tsx",
                        lineNumber: 21,
                        columnNumber: 11
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("strong", {
                                children: "Editor:"
                            }, void 0, false, {
                                fileName: "[project]/src/components/debug-panel.tsx",
                                lineNumber: 25,
                                columnNumber: 13
                            }, this),
                            " ",
                            activeProjectId || 'None',
                            " | Time: ",
                            currentTime,
                            "s | Playing: ",
                            playing ? 'Yes' : 'No'
                        ]
                    }, void 0, true, {
                        fileName: "[project]/src/components/debug-panel.tsx",
                        lineNumber: 24,
                        columnNumber: 11
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/src/components/debug-panel.tsx",
                lineNumber: 20,
                columnNumber: 9
            }, this)
        }, void 0, false, {
            fileName: "[project]/src/components/debug-panel.tsx",
            lineNumber: 19,
            columnNumber: 7
        }, this)
    }, void 0, false, {
        fileName: "[project]/src/components/debug-panel.tsx",
        lineNumber: 18,
        columnNumber: 5
    }, this);
}
}),
"[project]/src/components/debug-shortcuts.tsx [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "DebugShortcuts",
    ()=>DebugShortcuts
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$hooks$2f$use$2d$toast$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/hooks/use-toast.ts [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$analytics$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/analytics.ts [app-ssr] (ecmascript)");
'use client';
;
;
;
function DebugShortcuts() {
    const { toast } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$hooks$2f$use$2d$toast$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useToast"])();
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useEffect"])(()=>{
        // Only run on client side
        if ("TURBOPACK compile-time truthy", 1) return;
        //TURBOPACK unreachable
        ;
        const handleKeyDown = undefined;
    }, [
        toast
    ]);
    return null;
}
}),
];

//# sourceMappingURL=%5Broot-of-the-server%5D__e460185f._.js.map