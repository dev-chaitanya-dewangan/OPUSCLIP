var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/debug/seed/route.js")
R.c("server/chunks/[root-of-the-server]__9478a473._.js")
R.c("server/chunks/node_modules_next_d18cb976._.js")
R.m(61375)
R.m(48185)
module.exports=R.m(48185).exports
