var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/debug/reset/route.js")
R.c("server/chunks/[root-of-the-server]__cdd5a9fe._.js")
R.c("server/chunks/node_modules_next_d18cb976._.js")
R.m(70085)
R.m(38824)
module.exports=R.m(38824).exports
