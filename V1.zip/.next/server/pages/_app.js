var R=require("../chunks/ssr/[turbopack]_runtime.js")("server/pages/_app.js")
R.c("server/chunks/ssr/[root-of-the-server]__a6213e44._.js")
R.m(6555)
module.exports=R.m(6555).exports
