var R=require("../chunks/ssr/[turbopack]_runtime.js")("server/pages/_document.js")
R.c("server/chunks/ssr/[root-of-the-server]__cf840a8d._.js")
R.c("server/chunks/ssr/[root-of-the-server]__f1341afc._.js")
R.m(39141)
module.exports=R.m(39141).exports
