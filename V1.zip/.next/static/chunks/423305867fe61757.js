__turbopack_load_page_chunks__("/_app", [
  "static/chunks/a41dbe67f1447a5e.js",
  "static/chunks/29adffd9bc8b9ea7.js",
  "static/chunks/turbopack-7e8c6d9eaff77f4a.js"
])
