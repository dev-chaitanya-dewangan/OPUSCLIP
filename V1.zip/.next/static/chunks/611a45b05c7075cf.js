__turbopack_load_page_chunks__("/_error", [
  "static/chunks/b32851cd04a9508b.js",
  "static/chunks/29adffd9bc8b9ea7.js",
  "static/chunks/turbopack-b4a1132b6db3fceb.js"
])
