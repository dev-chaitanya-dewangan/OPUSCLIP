(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/[root-of-the-server]__f6202ce6._.css",
  "static/chunks/node_modules_374d4669._.js",
  "static/chunks/src_d3b77988._.js"
],
    source: "dynamic"
});
